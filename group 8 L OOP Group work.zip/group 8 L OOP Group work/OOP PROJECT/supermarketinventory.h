#ifndef SUPERMARKETINVENTORY_H
#define SUPERMARKETINVENTORY_H

#include "InventoryManager.h"
#include <fstream>
#include <iostream>
#include <sstream> // For stringstream
#include <algorithm> // For std::remove_if

class SupermarketInventory : public InventoryManager {
public:
    // Add a product to the inventory
    void addProduct(std::shared_ptr<Product> product) override {
        inventory.push_back(product);
    }

    // Display all products in the inventory
    void displayAllProducts() const override {
        if (inventory.empty()) {
            std::cout << "No products in inventory." << std::endl;
            return;
        }

        for (const auto& product : inventory) {
            product->displayInfo();
            std::cout << "Discount: $" << product->calculateDiscount() << std::endl;
        }
    }

    // Save the inventory to a file
    void saveInventoryToFile() override {
        std::ofstream outFile("inventory.txt");
        if (!outFile) {
            std::cerr << "Error opening file to save!" << std::endl;
            return;
        }

        for (const auto& product : inventory) {
            outFile << product->getName() << ","
                    << product->getPrice() << ","
                    << product->getStock() << std::endl;
        }
        outFile.close();
    }

    // Load the inventory from a file
    void loadInventoryFromFile() override {
        std::ifstream inFile("inventory.txt");
        if (!inFile) {
            std::cerr << "Error opening file to load!" << std::endl;
            return;
        }

        std::string line;
        while (std::getline(inFile, line)) {
            // Split the line into name, price, and stock
            std::istringstream ss(line);
            std::string name;
            double price;
            int stock;

            // Assuming the format in the file is "name, price, stock"
            std::getline(ss, name, ',');  // Get the product name
            if (!(ss >> price)) {
                std::cerr << "Invalid price for product: " << name << std::endl;
                continue;
            }
            ss.ignore(); // Ignore the comma after price
            if (!(ss >> stock)) {
                std::cerr << "Invalid stock for product: " << name << std::endl;
                continue;
            }

            // Add the product to the inventory
            addProduct(std::make_shared<GroceryProduct>(name, price, stock));
        }

        inFile.close();
    }

    // Remove a product from the inventory based on its name
    void removeProduct(const std::string& productName) {
        auto it = std::remove_if(inventory.begin(), inventory.end(),
                                 [&productName](const std::shared_ptr<Product>& product) {
                                     return product->getName() == productName;
                                 });

        if (it != inventory.end()) {
            inventory.erase(it, inventory.end());
            std::cout << "Product removed successfully.\n";
        } else {
            std::cout << "Product not found.\n";
        }
    }
};

#endif
