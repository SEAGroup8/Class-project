#include <iostream>
#include <limits> // For std::numeric_limits
#include <memory> // For std::shared_ptr
#include <string>
#include "SupermarketInventory.h"
#include "Grocery.h"
#include "Electronics.h"

// Function to display the menu
void displayMenu() {
    std::cout << "Supermarket Inventory Menu:\n";
    std::cout << "1. Add Product\n";
    std::cout << "2. Display All Products\n";
    std::cout << "3. Save Inventory to File\n";
    std::cout << "4. Load Inventory from File\n";
    std::cout << "5. Remove Product\n";
    std::cout << "6. Exit\n";
    std::cout << "Enter your choice: ";
}

int main() {
    SupermarketInventory inventory;
    int choice;

    do {
        displayMenu();
        std::cin >> choice;

        // Validate the input
        if (std::cin.fail()) {
            std::cin.clear();  // Clear input buffer
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Ignore invalid input
            std::cout << "Invalid input! Please enter a number.\n";
            continue;  // Skip the rest of the loop and ask for valid input
        }

        switch (choice) {
            case 1: {
                int type;
                std::string name;
                double price;
                int quantity;

                std::cout << "\nSelect Product Type:\n1. Grocery\n2. Electronics\nEnter your choice: ";
                std::cin >> type;
                std::cin.ignore(); // Clear newline character

                std::cout << "Enter Product Name: ";
                std::getline(std::cin, name);
                std::cout << "Enter Price: ";
                std::cin >> price;
                std::cout << "Enter Stock Quantity: ";
                std::cin >> quantity;

                if (type == 1) {
                    inventory.addProduct(std::make_shared<Grocery>(name, price, quantity));
                } else if (type == 2) {
                    inventory.addProduct(std::make_shared<Electronics>(name, price, quantity));
                } else {
                    std::cout << "Invalid Product Type!\n";
                }
                break;
            }
            case 2:
                inventory.displayAllProducts();
                break;
            case 3:
                inventory.saveInventoryToFile();
                std::cout << "Inventory saved to file.\n";
                break;
            case 4:
                inventory.loadInventoryFromFile();
                std::cout << "Inventory loaded from file.\n";
                break;
            case 5: {
                std::string productName;
                std::cout << "Enter the name of the product to remove: ";
                std::cin.ignore();  // Clear input buffer
                std::getline(std::cin, productName);
                inventory.removeProduct(productName);
                break;
            }
            case 6:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice! Please try again.\n";
        }

    } while (choice != 6);  // Loop will break if choice is 6

    return 0;
}
